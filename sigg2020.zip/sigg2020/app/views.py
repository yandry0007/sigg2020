from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse,HttpResponseRedirect
from django.core.paginator import Paginator,EmptyPage,InvalidPage
from django.views.generic import FormView
from django.views.generic import ListView
from django.template import RequestContext
from django.core.mail import EmailMessage
from .models import *
from .forms import *

def index_view(request):
	usuario=request.user
	return render(request, 'index.html', {'usuario':usuario})

def registrar_view(request):
	info = "inicializando"
	if request.method == "POST":
		form = LoginForm2(request.POST)
		if form.is_valid():
			form.save()
			info = "Usuario Registrado Satisfactoriamente!!"
			ctx = {'info':info}
			return render(request, 'registrado.html',ctx, )
	else:
		form = LoginForm2()
	ctx = {'form':form,'info':info}
	return render(request, 'registrado.html',ctx, )

from django.shortcuts import get_object_or_404

def validarCedula(cedula):
    if (len(cedula)!=10):
        return False
    else:
        #COMPROBAR NUMERO DE PROVINCIAS
        if (int(cedula[0: 2])<0 or int (cedula[0:2])>24 ):
            return False
        else:
            aux=0
            suma=0;
            for i in range (0,9):
                if ((i%2 == 0) or (i==0)):
                    aux=(int(cedula[i]))*2
                    suma = suma + (aux-9) if (aux>9) else suma+(aux)
                else:
                    suma=suma+(int(cedula[i]))
            if suma>10:
                aux2=str(suma+10)
                sumat=(int(aux2[0]+"0")-suma)
            else:
                sumat=suma
            if ((sumat==10 ) and int(cedula[9])==0):
                return True;
            else:
                if (sumat==int(cedula[9])):
                    return True;
                else:
                    return False;

#DEVOLVER UN USUARIO UNICO
@login_required(login_url='/login/')
def graduado(request):
	info = "inicializando"
	if request.method == "POST":
		form = PerfilForm(request.POST, request.FILES)
		cedula = Perfiles.objects.filter(cedula=request.POST.get('cedula'))															#en el input debe ser name=cedula para recogerlo en el POST con get('cedula') ok 
		validacion=validarCedula(request.POST.get('cedula'))
		if cedula:
			form = PerfilForm()
			ctx = { 'form':form , 'cedula_existe':True,'info':info}
			return render(request, 'graduado.html',ctx)
		if validacion == False:
			form = PerfilForm()
			ctx = { 'form':form ,'valida_cedula':True,'info':info}
			return render(request, 'graduado.html',ctx)
		if form.is_valid():
			profile = form.save(commit=False)
			profile.usuario = request.user
			profile.save()
			info = "Datos guardados sastisfatoriamente"
			ctx = {'info':info}
			return render(request, 'graduado.html',ctx)
		else:
			print ("Dato nooo guardado")
			err = "ERROR AL GUARDAR EL PERFIL VERIFIQUE QUE TODOS LOS CAMPOS ESTEN LLENOS.."
			return render(request, 'graduado.html',{'info':info,'err':err})
	else:
		perfil = Perfiles.objects.filter(usuario=request.user)
		usuario=request.user
		if perfil:
			return render(request, 'graduado.html', {'perfil':perfil,'usuario':usuario })
		else:
			form = PerfilForm()
			return render(request, 'graduado.html', {'form':form,'usuario':usuario, 'info':info })

def logout_view(request):
	logout(request)
	return HttpResponseRedirect('/login/')


def login_view(request):
	mensaje = ""
	if request.user.is_authenticated:
		return HttpResponseRedirect('/graduado/')  #ENVIAR AEL PERFIL DEL USUARIO
	else:
		if request.method == 'POST':
			form = LoginForm(request.POST)
			if form.is_valid():
				username = form.cleaned_data['username']
				password = form.cleaned_data['password']
				usuario = authenticate(username=username,password=password)
				if usuario is not None and usuario.is_active:
					login(request,usuario)
					return HttpResponseRedirect('/graduado/') #ENVIAR EL PERFIL DEL USUARIO
				else:
					mensaje = "* Usuario y/o password incorrectos"
		form = LoginForm()
		ctx = {'form':form,'mensaje': mensaje}
		return render(request, 'login.html',ctx)

@login_required(login_url='/login/')
def editar_view(request,id):
	perfil = Perfiles.objects.get(id=id)
	if request.method == 'POST':
		form = PerfilForm(request.POST,request.FILES, instance=perfil)
		if form.is_valid():
			profile = form.save(commit=False)
			profile.usuario = request.user
			profile.save()
			info = "Datos actualizados sastisfatoriamente"
			ctx = {'info':info}
			return render(request, 'graduado.html',ctx)
			#return HttpResponseRedirect('/graduado/')
		else:
			form = PerfilForm(instance=perfil)
	else:
		form = PerfilForm(instance=perfil)			
	return render(request, 'editar_graduado.html', {'perfil':perfil, 'form':form})
