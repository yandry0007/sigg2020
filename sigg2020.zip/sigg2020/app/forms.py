from django import forms
from django.contrib.admin import widgets 
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import *

class LoginForm(forms.Form):
  username = forms.CharField(widget=forms.TextInput())
  password = forms.CharField(widget=forms.PasswordInput(render_value=False))

  class Meta:
    model = User
    fields = ["username", "password"]

class LoginForm2(UserCreationForm):
  username = forms.EmailField(label="Correo electrónico")
  class Meta:
    model = User
    fields = ["username", "password1", "password2"]

class PerfilForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
       super(PerfilForm, self).__init__(*args, **kwargs)
       self.fields['fecha_nacimiento'].widget.attrs['readonly'] = True
       self.fields['fecha_ingreso'].widget.attrs['readonly'] = True
       self.fields['fecha_egreso'].widget.attrs['readonly'] = True
       self.fields['fecha_graduacion'].widget.attrs['readonly'] = True
       self.fields['fecha_inicio_otro'].widget.attrs['readonly'] = True
       self.fields['fecha_final_otro'].widget.attrs['readonly'] = True
       self.fields['fecha_inicio_laboral'].widget.attrs['readonly'] = True
       self.fields['fecha_final_laboral'].widget.attrs['readonly'] = True

    class Meta:
        model = Perfiles
        fields = '__all__'

class FormularioForm(forms.ModelForm):

    class Meta:
        model = Perfiles

        fields = [
            'nombres',
            'correo_origen',
            'telefono',
            'fecha_nacimiento',
        ]
        labels = {
            'nombres':'Nombre',
            'correo_origen':'Email',
            'telefono':'Telefono',
            'fecha_nacimiento': 'Fecha N',
        }
        widgets = {
            'nombres': forms.TextInput(attrs={'class': 'form-control full-width',
                                             'id' : 'contactName',
                                             'placeholder' : 'Your Name',
                                             'value' : '',
                                             'minlength' : '2',
                                             'required' : '',
                                             'aria-required' : 'true'}),

            'correo_origen': forms.TextInput(attrs={'class':'form-control'}),
            'telefono': forms.TextInput(attrs={'class':'form-control'}),
        }

#AGREGAR EL CORREO EN VEZ DEL USUARIO EN EL ADMINISTRADOR 
#LINK: https://www.hektorprofe.net/tutorial/extender-usercreationform-registro-email