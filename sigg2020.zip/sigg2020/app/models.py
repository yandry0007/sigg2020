from django.db import models
from django.contrib.auth.models import User
from django.utils.safestring import mark_safe


tipo_institucion = [
    ('PÚBLICA', 'PÚBLICA'),
    ('PRIVADA', 'PRIVADA'),
    ('OTROS', 'OTROS'),
]
tipo_ambito = [
    ('LOCAL', 'LOCAL'),
    ('REGIONAL', 'REGIONAL'),
    ('INTERNACIONAL', 'INTERNACIONAL'),
]
nivel_estudios = [
    ('TÉCNICO SUPERIOR', 'TÉCNICO SUPERIOR'),
    ('TERCER NIVEL', 'TERCER NIVEL'),
    ('POSTGRADO', 'POSTGRADO'),
]
carreras_istpm = [
    ('Tecnología Superior en Desarrollo de Software', 'Tecnología Superior en Desarrollo de Software'),
    ('Tecnología Superior en Contabilidad', 'Tecnología Superior en Contabilidad'),
    ('Tecnología en Informática', 'Tecnología en Informática'),
    ('Tecnología en Contabilidad y Auditoría', 'Tecnología en Contabilidad y Auditoría'),
]
tipo_situacion = [
	('EMPLEADO', 'EMPLEADO'),
	('DESEMPLEADO', 'DESEMPLEADO'),
    ('CUENTA PROPIA', 'CUENTA PROPIA'),
]
titulo_obt = [
	('Tecnólogo(a) en Desarrollo de Software', 'Tecnólogo(a) en en Desarrollo de Software'),
    ('Tecnólogo(a) en Informática', 'Tecnólogo(a) en Informática'),
    ('Tecnólogo(a) en Contabilidad y Auditoría', 'Tecnólogo(a) en Contabilidad y Auditoría'),
    ('Tecnólogo(a) Superior en Contabilidad', 'Tecnólogo(a) Superior en Contabilidad'),
]
estado_estu = [
	('GRADUADO', 'GRADUADO'),
    ('EGRESADO', 'EGRESADO'),
]
provincia = [
	('Azuay', 'Azuay'),
	('Bolívar', 'Bolívar'),
	('Cañar', 'Cañar'),
	('Carchi', 'Carchi'),
	('Chimborazo', 'Chimborazo'),
	('Cotopaxi', 'Cotopaxi'),
	('El Oro', 'El Oro'),
	('Esmeraldas', 'Esmeraldas'),
	('Galápagos', 'Galápagos'),
	('Guayas', 'Guayas'),
	('Imbabura', 'Imbabura'),
	('Loja', 'Loja'),
	('Los Ríos', 'Los Ríos'),
	('Manabí', 'Manabí'),
	('Morona Santiago', 'Morona Santiago'),
	('Napo', 'Napo'),
	('Orellana', 'Orellana'),
	('Pastaza', 'Pastaza'),
	('Pichincha', 'Pichincha'),
	('Santa Elena', 'Santa Elena'),
	('Santo Domingo de los T.', 'Santo Domingo de los T.'),
	('Sucumbíos', 'Sucumbíos'),
	('Tungurahua', 'Tungurahua'),
    ('Zamora Chinchipe', 'Zamora Chinchipe'),
    ('Otras...', 'Otras...'),
]

def url(self, filename):
	ruta = "static/graduados/img/Perfiles/%s/%s"%(self.usuario.username,str(filename))
	return ruta

class Perfiles(models.Model):

	def foto_perfil(self):
		return mark_safe('<a href="/%s"><img src="/%s" width=50px height=50px/></a>'%(self.foto, self.foto))
	#DATOS PERSONALES
	usuario = models.OneToOneField(User,on_delete=models.CASCADE, blank=True)
	nombres = models.CharField(blank=False, max_length=30)
	apellidos = models.CharField(blank=False, max_length=30)
	cedula = models.CharField(blank=False,max_length=10,unique=True) 
	telefono = models.CharField(blank=True, max_length=10) 
	celular = models.CharField(blank=False, max_length=10)
	foto = models.ImageField(upload_to=url)
	pais_origen = models.CharField(blank=False, max_length=30)
	provincia_origen = models.CharField(max_length=30,choices=provincia,default='available')
	ciudad_residencia = models.CharField(blank=False, max_length=30)
	direccion = models.CharField(blank=False, max_length=30)
	correo_origen = models.EmailField(blank=False)
	hombre = models.BooleanField(blank=True, default=False)
	mujer = models.BooleanField(blank=True, default=False)
	fecha_nacimiento = models.DateField(blank=False, null=True)
	#DATOS ACADEMICOS
	estado = models.CharField(max_length=80,choices=estado_estu,default='available')
	carrera = models.CharField(max_length=80,choices=carreras_istpm,default='available')
	nivel_estudio = models.CharField(max_length=80,choices=nivel_estudios,default='available')
	fecha_ingreso = models.DateField(blank=False, null=True)
	fecha_egreso = models.DateField(blank=False, null=True)
	fecha_graduacion = models.DateField(blank=True, null=True)
	titulo_obtenido = models.CharField(blank=True, max_length=80,choices=titulo_obt,default='available')
	tema_grado = models.CharField(blank=True, max_length=30)
	#DATOS DE OTROS ESTUDIOS REALIZADOS  PONER BLANK = TRUE
	institucion_otro = models.CharField(blank=True, max_length=30)
	nivel_estudio_otro = models.CharField(blank=True, max_length=80, choices=nivel_estudios,default='available')
	fecha_inicio_otro = models.DateField(blank=True, null=True)
	fecha_final_otro = models.DateField(blank=True, null=True)
	titulo_obtenido_otro = models.CharField(blank=True, max_length=30)
	tema_grado_otro = models.CharField(blank=True, max_length=30)
	#DATOS LABORALES
	situacion = models.CharField(max_length=15,choices=tipo_situacion,default='available')
	institucion_laboral = models.CharField(blank=True, max_length=30)
	tipo_institucion_laboral = models.CharField(blank=True,max_length=80,choices=tipo_institucion,default='available',)
	ambito = models.CharField(blank=True,max_length=15,choices=tipo_ambito,default='available',)
	cargo_ocupa = models.CharField('Cargo',blank=True, max_length=30)
	nombre_jefe = models.CharField(blank=True, max_length=30)
	telefono_oficina = models.CharField(blank=True, max_length=10)
	email_laboral = models.EmailField(blank=True) 
	direccion_trabajo = models.CharField(blank=True, max_length=30)
	fecha_inicio_laboral = models.DateField(blank=True, null=True)
	fecha_final_laboral = models.DateField(blank=True, null=True)
	pais_laboral = models.CharField(blank=True, max_length=30)
	provincia_laboral = models.CharField(blank=True,max_length=80, choices=provincia,default='available',)
	ciudad_laboral = models.CharField(blank=True, max_length=30)



	def __str__(self):
		return self.usuario.username

	class Meta:
		verbose_name = 'ADMINISTRAR DATOS DE LOS ESTUDIANTES'
		verbose_name_plural = 'ADMINISTRAR DATOS DE LOS ESTUDIANTES'

