from django.contrib import admin
from .models import *
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from import_export import resources
from import_export.admin import ImportExportModelAdmin

class BookResource(resources.ModelResource):
	class Meta:
		model = Perfiles

class BookAdmin(ImportExportModelAdmin):
	list_display = ('cedula','nombres','apellidos','carrera','estado','celular','pais_origen',
	'provincia_origen','direccion','correo_origen','ciudad_residencia','foto_perfil')
	search_fields = ['usuario__username','cedula','nombres','apellidos','provincia_origen',
	'direccion','ciudad_residencia','carrera','estado','fecha_graduacion']
	fieldsets = [
		('INFORMACION DE DATOS PERSONALES', {'fields': 
		['usuario', 'nombres', 'apellidos', 'cedula','telefono','celular','foto',
		'pais_origen', 'provincia_origen', 'ciudad_residencia', 'direccion','correo_origen',
		'fecha_nacimiento','hombre','mujer']
		} ),
        #('Infromacion de la Fecha y hora', {'fields': ['pais'], 'classes': ['collapse'] }),  #Collapse sirve para ocultar o mostrar (mas) 
        ('INFORMACION DE DATOS ACADEMICOS', {'fields': 
        ['carrera', 'estado', 'nivel_estudio', 'fecha_ingreso','fecha_egreso','fecha_graduacion',
        'titulo_obtenido','tema_grado', ]
		} ),

		('INFORMACION DE OTROS ESTUDIOS REALIZADOS', {'fields': 
        ['institucion_otro', 'nivel_estudio_otro','fecha_inicio_otro','fecha_final_otro',
        'titulo_obtenido_otro','tema_grado_otro',]
		} ),

		('INFORMACION DE DATOS LABORALES', {'fields': 
        ['institucion_laboral', 'tipo_institucion_laboral', 'ambito', 'situacion',
        'direccion_trabajo','fecha_inicio_laboral','fecha_final_laboral',
        'cargo_ocupa', 'nombre_jefe', 'telefono_oficina','email_laboral',
        'pais_laboral','provincia_laboral','ciudad_laboral',
        ]
		} ),
    ]

	resource_class = BookResource

admin.site.register(Perfiles, BookAdmin)
